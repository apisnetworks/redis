Flush the Lua scripts cache.

Please refer to the `EVAL` documentation for detailed information about Redis
Lua scripting.

@return

@simple-string-reply
